package com.example.retoDos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetoDosApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetoDosApplication.class, args);
	}

}
